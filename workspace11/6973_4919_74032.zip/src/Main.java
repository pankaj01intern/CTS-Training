import java.util.*;

class Main{
    
    public static void main(String args[]){
        
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int m=4;
        int l=6,k;
        System.out.print("2"+" "+"6 ");
        for(int i=2;i<n;i++){
    		 k=(m*i) +1+l;
    		 l=k;
    		 System.out.print(k+" ");
   
     }

        
        
     	}
    }

    
    
    