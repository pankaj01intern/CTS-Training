public class PlayerBO {
	
	public static void viewDetails(Player[] playerList){
		System.out.println(String.format("%-15s %-15s %-15s","Player","Country","Skill"));
		for(int i=0;i<playerList.length;i++){
			System.out.println(playerList[i]);
		}
		
	}
	
	public static void printPlayerDetailsWithSkill(Player[] playerList, String skill){
		System.out.println(String.format("%-15s %-15s %-15s","Player","Country","Skill"));
		for(int i=0;i<playerList.length;i++){
			if(playerList[i].getSkill().getSkillName().equals(skill)){
			System.out.println(playerList[i]);
			}
		}
	}

}
