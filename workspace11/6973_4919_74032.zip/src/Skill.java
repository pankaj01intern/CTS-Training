public class Skill {

	private String skillName;
	
	
	public Skill(){
		
	}

	public Skill(String skillName) {
		this.skillName = skillName;
	}

	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	
	
	@Override
	public String toString() {
		return String.format("%-15s",skillName);
	}
}
