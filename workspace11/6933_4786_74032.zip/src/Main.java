import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of venues");
		int n=sc.nextInt();
		sc.nextLine();
		int i=1;
		String[] input=new String[n];
		while(i<=n) {
			System.out.println("Enter the details of venue "+i);
			input[i-1]=sc.nextLine();
			i++;
		}
		System.out.println("Venue Details");
		for(int j=0;j<n;j++) {
			String[] s=input[j].split(",");
			Venue v=new Venue(s[0],s[1]);
			System.out.println(v.toString());
		}
		
	}

}