import java.util.Scanner;
class Main{
    public static void main(String... args){
        Scanner sc=new Scanner(System.in);
        float a=sc.nextFloat();
        float b=sc.nextFloat();
        float c=((a*6*0.5f)+(b*5*0.4f));
        System.out.printf("%.2f",c);
        
    }
}