
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of innings");
		int n=sc.nextInt();
		int i=1;
		
		Object[] obj=new Object[n];
		while(i<=n){
			sc.nextLine();
			//Scanner sc1=new Scanner(System.in);
		System.out.println("Enter the values for Innings "+i);
		System.out.println("Enter the BattingTeam");
		String battingTeam=sc.nextLine();
		
		System.out.println("Enter the runs scored");
		//Scanner sc2=new Scanner(System.in);
		Long runs=sc.nextLong();
		
		
		
		obj[i-1]=new Innings(battingTeam, runs);
		i++;
	}
		//sc.close(); 
		i=1;
		System.out.println("Innings Details");
		
		for(Object ob:obj){
			System.out.println("Innings "+i++);
			System.out.println(ob.toString());
		}
	}
}
