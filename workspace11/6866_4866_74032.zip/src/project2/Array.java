package project2;

import java.util.Arrays;

abstract class A{
	A(){
		
	}
}
public class Array extends A{
	
    A a=new Array();
    //A a=new A();
 public static void main (String args[]) throws Exception {
	 
	 byte n='a';
	 String s=n+"";                 
	int b='o';
	System.out.println(n);
	 System.out.println(s);
 
}
}

	


