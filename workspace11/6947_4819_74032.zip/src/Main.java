import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Innings[] innings=new Innings[2];
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the values for FirstInnings\nEnter the BattingTeam");
		String bf=sc.nextLine();
		System.out.println("Enter the runs scored");
		long runf=sc.nextLong();
		sc.nextLine();
		Innings i1=new Innings(bf,runf);
		innings[0]=i1;
		System.out.println("Enter the values for SecondInnings\nEnter the BattingTeam");
		String bs=sc.nextLine();
		System.out.println("Enter the runs scored");
		long runs=sc.nextLong();
		Innings i2=new Innings(bs,runs);
		innings[1]=i2;
		
		InningsBO.displayAllInningsDetails(innings);
		sc.close();
	}

}