public class InningsBO {

	static void displayAllInningsDetails(Innings[] inningsList) {
		System.out.println("Innings Details");
		System.out.println(String.format("%-20s %-20s",inningsList[0].getBattingTeam(),inningsList[0].getRuns()));
		System.out.println(String.format("%-20s %-20s",inningsList[1].getBattingTeam(),inningsList[1].getRuns()));
	}
	
}