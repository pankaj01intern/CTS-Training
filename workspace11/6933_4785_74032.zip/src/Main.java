import java.util.Scanner;

import javax.swing.plaf.synth.SynthToggleButtonUI;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the over");
		long over=sc.nextLong();
		sc.nextLine();
		
		System.out.println("Enter the ball");
		long ball=sc.nextLong();
		sc.nextLine();
		
		System.out.println("Enter the runs");
		long runs=sc.nextLong();
		sc.nextLine();
		
		System.out.println("Enter the batsman name");
		String batsman=sc.nextLine();
		
		System.out.println("Enter the bowler name");
		String bowler=sc.nextLine();
		
		System.out.println("Enter the nonStriker name");
		String nonStriker=sc.nextLine();
		
		Delivery d=new Delivery(over,ball,runs,batsman,bowler,nonStriker);
		
		System.out.println(d.toString());

	}

}