public class PlayerBO {
	
	static void displayAllPlayerDetails(Player[] playerList) {
		System.out.println("Player Details");
		for(int i=0;i<playerList.length;i++) {
		System.out.println(String.format("%-15s %-15s %-15s",playerList[i].getName(),playerList[i].getCountry(),playerList[i].getSkill()));
	}

}
}