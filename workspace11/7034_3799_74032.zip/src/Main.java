import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Player name");
		String s=sc.next();
		String s2=sc.next();
		String s3[]=s.split(" ");
		String s4[]=s2.split(" ");
				if(s3[0].equals(s4[0]))
					System.out.println("Both the players names starts with "+s3[0]);
				
				else
					System.out.println("Both the players names does not starts with "+s3[0]);
		
			
	}
	
}