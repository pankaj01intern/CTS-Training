
public class UserMainCode {
	
	public static int largestChunk(String s){
		 String sar[]=s.split(" ");
		 
		 int max=1;
		 int max2=-1;
		int n=s.length();
		
		for(int j=0;j<sar.length;j++){
		
		for(int i=0;i<sar[j].length()-1;i++){
			if(sar[j].charAt(i)==sar[j].charAt(i+1)){
				max=max+1;
			}
		}
		  if(max > max2)
			  max2=max;
		
		}
		
		return max2;
	}

}
