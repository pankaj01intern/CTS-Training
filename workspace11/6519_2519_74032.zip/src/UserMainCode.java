import java.util.ArrayList;
import java.util.List;

public class UserMainCode {
	
	public static int getYear(ArrayList<Integer> list){
		
		int max=0;
		int index=0;
		for(int i=1;i<list.size();i=i+2){
			if(list.get(i) > max){
				max=list.get(i);
				index=i-1;
			}
			
		}
		int res=list.get(index);
		return res;
	}

}
