import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		ArrayList<Integer> list=new ArrayList<Integer>();
		for(int i=0;i<2*n;i++)
			list.add(sc.nextInt());
		
		int res=UserMainCode.getYear(list);
		System.out.println(res);
		

	}

}
