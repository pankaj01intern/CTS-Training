import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number of matches");
		int n=sc.nextInt();
		sc.nextLine();
		
		Outcome[] outcome=new Outcome[n];
		
		for(int i=1;i<=n;i++){
			System.out.println("Enter match "+i+" details");
			System.out.println("Enter the date");
			String date=sc.nextLine();
			System.out.println("Enter the status");
			String status=sc.nextLine();
			System.out.println("Enter the winner team");
			String win=sc.nextLine();
			System.out.println("Enter the player of match");
			String mof=sc.nextLine();
			
			Outcome o=new Outcome(date,status,win,mof);
			outcome[i-1]=o;
		}
		
		OutcomeBO.displayAllOutcomeDetails(outcome);
		
		System.out.println("Enter the date to be searhed");
		String dat=sc.nextLine();
		
		OutcomeBO.displaySpecificOutcomeDetails(outcome,dat);
		sc.close();
	}

}
